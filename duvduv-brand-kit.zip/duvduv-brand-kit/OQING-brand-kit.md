# duv • duv — brend to'plami (AI animatsiya uchun)

Bu papkadagi hamma narsa **ilovadan to'g'ridan-to'g'ri olingan** — ya'ni animatsiyada
ishlatilgan ikonka ilovadagi ikonkaning aynan o'zi bo'ladi.

---

## Ilova nima qiladi (animatsiya uchun kontekst)

**duv • duv** — O'zbekiston uchun Telegram Mini App. Bir yo'nalish bo'yicha
ketayotgan **haydovchi** bilan **yo'lovchi** yoki **yuk yuboruvchi**ni xaritada
bir-biriga topishtiradi.

Foydalanuvchi ilovani ochadi → xarita ko'rinadi → pastdagi **3 ta tugmadan
birini** tanlaydi → "Qayerdan → Qayerga" ni belgilaydi → e'lon xaritada paydo
bo'ladi va mos keladiganlar bir-birini ko'radi.

**Animatsiyaning asosiy g'oyasi shu bo'lishi kerak:** bir yo'lda turganlar
bir-birini topadi.

---

## Papkalar

| Papka | Nima bor | Qachon ishlatiladi |
|---|---|---|
| `1-ikonkalar/` | 3 ta asosiy 3D ikonka, shaffof fon, 240×240 PNG | **ASOSIY** — animatsiyaning bosh qahramonlari |
| `1-ikonkalar/kattalashtirilgan-1024/` | O'sha ikonkalar 1024×1024 ga cho'zilgan | AI vositalari ko'pincha ≥512px talab qiladi |
| `2-tugmalar/` | 3 ta tugma to'liq holida, shaffof fon, ~1400px | Animatsiya **oxirida** shu tugmalarga aylanishi kerak |
| `3-xarita-ikonkalari/` | Xaritada ishlatiladigan, oq doira ichidagi variant | Xarita sahnasi kerak bo'lsa |
| `4-logo/` | "duv • duv" logotipi, shaffof fon | Ochilish/yopilish kadri |
| `5-namuna/` | Ilovaning haqiqiy bosh ekrani | Animatsiya nimaga ulanishini ko'rsatadi |

> ⚠️ `kattalashtirilgan-1024` — bu oddiy cho'zish, **yangi detal qo'shilmagan**.
> Asl aniqlik 240px. Agar AI vositasi buni yetarli deb topmasa, ikonkani qayta
> 3D render qilish kerak bo'ladi.

---

## Ranglar

| Nima | Kod |
|---|---|
| Tugma — yorug' | `#7DA6D9` |
| Tugma — asosiy | `#2C5FA8` |
| Tugma — to'q | `#1B3E73` |
| Tugma — eng to'q (asos) | `#10254A` |
| Tugma matni | `#FFFFFF` |
| Logotipdagi nuqta | `#FF6B4A` |
| Logotip matni | `#0F172A` |
| Yashil — "Qayerdan" / haydovchi | `#22C55E` |
| Qizil — "Qayerga" | `#EF4444` |
| Ko'k — yuk | `#2AABEE` |
| To'q sariq — yo'lovchi | `#E8820A` |
| Xarita foni | `#ECE8E0` |
| Xaritadagi yo'llar | `#FFFFFF` |

**Shrift:** SF Pro Rounded / Segoe UI Rounded (zaxira: system-ui).
Tugma matni: **900 og'irlik, BOSH HARFLAR**, harflar orasi `+0.01em`.

---

## Matnlar

| Lotin | Kirill (ilovada shu ishlatiladi) |
|---|---|
| Yo'lovchiman | Йўловчиман |
| Yuk yuboraman | Юк юбораман |
| Haydovchiman | Ҳайдовчиман |
| Qayerdan? | Қаердан? |
| Qayerga? | Қаерга? |

> Ovoz uchun: agar Narakeet ishlatsangiz — u **faqat lotin** o'qiydi, kirill
> matnni oldin lotinga o'giring.

---

## Animatsiyaga qo'yiladigan talablar

1. **Ikonkalar shakli o'zgarmasin.** Parashyut parashyutligicha, mashina o'sha
   mashinaligicha qolsin. AI video modeli ularni "qayta chizib" yuborsa —
   kadr yaroqsiz. Har kadrni tekshiring.
2. **Oxirgi kadr `5-namuna/ilova-bosh-ekrani.png` ga o'xshasin.** Animatsiya
   interfeysga *ulanishi* kerak, kesilib qolmasin.
3. **Uzunligi: 3 soniya** (ko'pi bilan 4).
4. **Vertikal format 9:16** (720×1280).
5. Ikonkalar atrofida **oq kontur/xoshiya bo'lmasin**.

---

## Tayyor faylga qo'yiladigan texnik talablar

Zaif telefonlarda ham qotmasligi uchun:

```
Format   : MP4 / H.264 (Baseline yoki Main profil)
O'lcham  : 720 × 1280
Kadr     : 30 fps
Bitreyt  : ~1.2 Mbps
Hajmi    : 3 soniya ≈ 400–600 KB
Ovoz     : AAC, 64 kbps
Muhim    : moov atom faylning BOSHIDA (+faststart)
```

Ishlatmang: 4K, HEVC/H.265, VP9, AV1, shaffof WebM — bular Telegram ichidagi
brauzerda ishlamaydi yoki qotiradi.

**Lottie (JSON) eksport qilish imkoni bo'lsa — u afzal.** Hajmi ~50 KB bo'ladi
va video bilan bog'liq muammolarning hech biri chiqmaydi.

---

## ⚠️ Ovoz haqida — buni oldindan biling

Telegram ichidagi brauzer va barcha mobil brauzerlar **ovozli avtomatik ijroni
bloklaydi**. Ilova ochilishi bilan o'zi ishga tushadigan video **ovozsiz**
chiqadi — foydalanuvchi ekranga tegmaguncha ovoz yo'q. Bu qoida, chetlab
o'tib bo'lmaydi.

Shu sabab: ovozni animatsiyaning ma'nosiga **shart qilib qo'ymang**. Video
ovozsiz ham tushunarli bo'lsin, ovoz esa qo'shimcha bo'lsin.
